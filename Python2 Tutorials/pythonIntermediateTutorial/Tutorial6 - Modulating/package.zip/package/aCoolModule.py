#This is a module that belongs to a package.

#you can access this module with:

#import package.aCoolModule
