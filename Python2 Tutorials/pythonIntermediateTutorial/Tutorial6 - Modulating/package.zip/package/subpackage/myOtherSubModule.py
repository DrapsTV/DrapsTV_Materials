#This is a module that belongs to a subpackage.

#you can access this module with:

#import package.subpackage.myOtherSubModule
