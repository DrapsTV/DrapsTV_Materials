# This initalizes the subpackage folder.

# the __all__ special variable indicates what modules to load then the * star
# is used for importing.

__all__ = ['mySubModule', 'myOtherSubModule']
