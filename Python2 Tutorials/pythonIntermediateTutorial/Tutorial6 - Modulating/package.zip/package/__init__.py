# This makes this folder a package and can be left empty if you like.

# the __all__ special variable indicates what modules to load then the * star
# is used for importing.

__all__ = ['aCoolModule']
